// Background service worker
const GITHUB_BASE = "https://raw.githubusercontent.com/Eniamza/snip/refs/heads/main/";

chrome.commands.onCommand.addListener((command) => {
  if (command === "activate-typer") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "activate" });
      }
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "loadSnippet") {
    loadSnippetFromGitHub(message.key).then(sendResponse);
    return true;
  }
  if (message.action === "askGPT") {
    askGPT(message.text).then(sendResponse);
    return true;
  }
  if (message.action === "copyToClipboard") {
    return true;
  }
});

async function loadSnippetFromGitHub(key) {
  const extensions = ['.py', '.txt', '.js', '.json', '.md', '.html', '.css', ''];
  
  for (const ext of extensions) {
    const filename = `${key}${ext}`;
    const url = GITHUB_BASE + filename;
    
    try {
      const response = await fetch(url);
      if (response.ok) {
        const content = await response.text();
        await copyToClipboard(content);
        return { success: true, filename };
      }
    } catch (e) {
      continue;
    }
  }
  
  return { success: false, error: "File not found" };
}

async function askGPT(text) {
  try {
    const result = await chrome.storage.local.get(['openaiApiKey']);
    const apiKey = result.openaiApiKey;
    
    if (!apiKey) {
      console.error("No API key configured");
      return { success: false, error: "No API key configured" };
    }

    console.log("Sending to GPT:", text);

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-5.2-chat-latest',
        messages: [
          {
            role: 'developer',
            content: [
              {
                type: 'text',
                text: 'You are a Python coding assistant. Respond ONLY with Python code, no explanations, no markdown code blocks, no backticks. Just pure Python code that solves the problem. You can ONLY use numpy and matplotlib libraries. Use numpy for array manipulation, multiplication, and matrix inversion when needed. You can only use numpy.array numpy.zeros numpy.ones numpy.dot numpy.linalg.inv matplotlib.pyplot.plot matplotlib.pyplot.show for plotting data.'
              }
            ]
          },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: text
              }
            ]
          }
        ],
        response_format: {
          type: 'text'
        },
        store: false
      })
    });

    const data = await response.json();
    
    if (!response.ok) {
      console.error("API error:", data);
      return { success: false, error: data.error?.message || 'API request failed' };
    }

    let code = data.choices[0].message.content;
    
    // Clean up any markdown code blocks if included
    code = code.replace(/^```python\n?/i, '').replace(/^```\n?/, '').replace(/\n?```$/g, '').trim();
    
    console.log("Code received:", code.substring(0, 100) + "...");
    
    await copyToClipboard(code);
    return { success: true, code };
  } catch (err) {
    console.error("GPT fetch error:", err);
    return { success: false, error: err.message };
  }
}

async function copyToClipboard(text) {
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['CLIPBOARD'],
      justification: 'Copy snippet to clipboard'
    });
  } catch (e) {}
  
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'copyToClipboard', text }, resolve);
  });
}
