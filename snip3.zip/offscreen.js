chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'copyToClipboard') {
    navigator.clipboard.writeText(message.text).then(() => {
      sendResponse({ success: true });
    }).catch(err => {
      // Fallback method
      const textarea = document.createElement('textarea');
      textarea.value = message.text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      sendResponse({ success: true });
    });
    return true;
  }
});
