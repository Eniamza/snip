document.addEventListener('DOMContentLoaded', () => {
  const apiKey = document.getElementById('apiKey');
  const saveBtn = document.getElementById('save');
  const status = document.getElementById('status');

  // Load saved key
  chrome.storage.local.get(['openaiApiKey'], (result) => {
    if (result.openaiApiKey) {
      apiKey.value = result.openaiApiKey;
    }
  });

  // Save
  saveBtn.addEventListener('click', () => {
    chrome.storage.local.set({ openaiApiKey: apiKey.value.trim() }, () => {
      status.textContent = '✓ Saved!';
      setTimeout(() => status.textContent = '', 2000);
    });
  });

  apiKey.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') saveBtn.click();
  });
});
