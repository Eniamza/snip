// Clipboard Typer - Content Script
(function() {
  let active = false;
  let clipboardText = "";
  let position = 0;
  let indicator = null;
  let waitingForSnippetKey = false;

  function showPixel(color) {
    if (indicator) indicator.remove();
    indicator = document.createElement("div");
    indicator.style.cssText = `
      position: fixed;
      bottom: 10px;
      right: 10px;
      width: 3px;
      height: 3px;
      background: ${color};
      z-index: 2147483647;
      pointer-events: none;
    `;
    document.body.appendChild(indicator);
  }

  function removeIndicator() {
    if (indicator) {
      indicator.remove();
      indicator = null;
    }
  }

  function deactivate() {
    active = false;
    clipboardText = "";
    position = 0;
    showPixel("#ff0000");
    setTimeout(removeIndicator, 500);
  }

  async function activate() {
    try {
      let text = await navigator.clipboard.readText();
      if (!text) return;
      // Normalize tabs to 4 spaces
      text = text.replace(/\t/g, '    ');
      clipboardText = text;
      position = 0;
      active = true;
      showPixel("#00ff00");
    } catch (err) {
      console.error("Clipboard read failed:", err);
    }
  }

  // Handle Alt+C + letter for snippet loading
  function handleSnippetKey(e) {
    if (!waitingForSnippetKey) return;
    
    const key = e.key.toUpperCase();
    if (/^[A-Z0-9]$/.test(key)) {
      e.preventDefault();
      e.stopPropagation();
      waitingForSnippetKey = false;
      
      // Request snippet from background
      chrome.runtime.sendMessage({ action: "loadSnippet", key: key }, (response) => {
        if (response && response.success) {
          showPixel("#00ffff"); // Cyan for snippet loaded
          setTimeout(removeIndicator, 500);
        } else {
          showPixel("#ff0000");
          setTimeout(removeIndicator, 500);
        }
      });
    } else if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      waitingForSnippetKey = false;
      removeIndicator();
    }
  }

  function getCodeMirrorInstance(element) {
    // Try to find CodeMirror instance
    let el = element;
    while (el) {
      if (el.CodeMirror) return el.CodeMirror;
      if (el.classList && el.classList.contains('CodeMirror')) {
        return el.CodeMirror;
      }
      el = el.parentElement;
    }
    
    // Colab-specific: try to find via querySelector
    const cmWrapper = document.querySelector('.CodeMirror');
    if (cmWrapper && cmWrapper.CodeMirror) {
      return cmWrapper.CodeMirror;
    }
    
    return null;
  }

  function insertChar(char, target) {
    // Check if we're in a CodeMirror editor (Colab uses this)
    const cm = getCodeMirrorInstance(target);
    if (cm) {
      const cursor = cm.getCursor();
      cm.replaceRange(char, cursor);
      // Disable auto-indent for this insertion
      return;
    }
    
    // For Monaco editor (VSCode-based editors)
    const monacoEditor = target.closest('.monaco-editor');
    if (monacoEditor) {
      document.execCommand("insertText", false, char);
      return;
    }

    const isNewline = char === '\n';
    
    // Method 1: Try InputEvent
    const inputEvent = new InputEvent("input", {
      inputType: isNewline ? "insertLineBreak" : "insertText",
      data: isNewline ? null : char,
      bubbles: true,
      cancelable: true,
    });
    
    // Method 2: Also dispatch beforeinput
    const beforeInputEvent = new InputEvent("beforeinput", {
      inputType: isNewline ? "insertLineBreak" : "insertText",
      data: isNewline ? null : char,
      bubbles: true,
      cancelable: true,
    });
    
    target.dispatchEvent(beforeInputEvent);
    
    // For contenteditable
    if (target.isContentEditable || target.contentEditable === "true") {
      const selection = window.getSelection();
      if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        
        if (isNewline) {
          const br = document.createElement('br');
          range.insertNode(br);
          range.setStartAfter(br);
          range.setEndAfter(br);
        } else {
          const textNode = document.createTextNode(char);
          range.insertNode(textNode);
          range.setStartAfter(textNode);
          range.setEndAfter(textNode);
        }
        
        selection.removeAllRanges();
        selection.addRange(range);
      }
      target.dispatchEvent(inputEvent);
    } 
    // For input/textarea elements
    else if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") {
      const start = target.selectionStart || 0;
      const end = target.selectionEnd || 0;
      const value = target.value;
      target.value = value.slice(0, start) + char + value.slice(end);
      target.selectionStart = target.selectionEnd = start + 1;
      target.dispatchEvent(inputEvent);
      target.dispatchEvent(new Event("change", { bubbles: true }));
    }
    // Fallback
    else {
      document.execCommand("insertText", false, char);
    }
  }

  function handleKeyDown(e) {
    // Handle snippet key selection when waiting
    if (waitingForSnippetKey) {
      handleSnippetKey(e);
      return;
    }

    // Alt+C to enter snippet selection mode
    if (e.altKey && e.key.toLowerCase() === "c") {
      e.preventDefault();
      e.stopPropagation();
      waitingForSnippetKey = true;
      showPixel("#ffff00"); // Yellow for waiting
      return;
    }

    // Alt+B to ask GPT about highlighted text
    if (e.altKey && e.key.toLowerCase() === "b") {
      e.preventDefault();
      e.stopPropagation();
      
      const selection = window.getSelection();
      const selectedText = selection ? selection.toString().trim() : "";
      
      if (!selectedText) {
        showPixel("#ff0000");
        setTimeout(removeIndicator, 500);
        console.log("No text selected");
        return;
      }
      
      console.log("Selected text:", selectedText);
      showPixel("#ff00ff"); // Magenta for GPT loading
      
      chrome.runtime.sendMessage({ action: "askGPT", text: selectedText }, (response) => {
        if (chrome.runtime.lastError) {
          console.error("Runtime error:", chrome.runtime.lastError);
          showPixel("#ff0000");
          setTimeout(removeIndicator, 500);
          return;
        }
        
        if (response && response.success) {
          console.log("GPT response received");
          showPixel("#00ffff"); // Cyan for ready
          setTimeout(removeIndicator, 500);
        } else {
          console.error("GPT error:", response?.error);
          showPixel("#ff0000");
          setTimeout(removeIndicator, 500);
        }
      });
      return;
    }

    if (!active) return;

    // Escape - deactivate
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      deactivate();
      return;
    }

    // Backspace - delete a character and go back one position
    if (e.key === "Backspace") {
      e.preventDefault();
      e.stopPropagation();
      
      const target = document.activeElement;
      
      // Delete character in the field
      if (target.isContentEditable || target.contentEditable === "true") {
        const selection = window.getSelection();
        if (selection.rangeCount > 0) {
          const range = selection.getRangeAt(0);
          if (!range.collapsed) {
            range.deleteContents();
          } else {
            range.setStart(range.startContainer, Math.max(0, range.startOffset - 1));
            range.deleteContents();
          }
        }
        target.dispatchEvent(new InputEvent("input", { inputType: "deleteContentBackward", bubbles: true }));
      } else if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") {
        const start = target.selectionStart || 0;
        const end = target.selectionEnd || 0;
        if (start === end && start > 0) {
          target.value = target.value.slice(0, start - 1) + target.value.slice(end);
          target.selectionStart = target.selectionEnd = start - 1;
        } else if (start !== end) {
          target.value = target.value.slice(0, start) + target.value.slice(end);
          target.selectionStart = target.selectionEnd = start;
        }
        target.dispatchEvent(new InputEvent("input", { inputType: "deleteContentBackward", bubbles: true }));
      }
      
      // Go back one position in clipboard
      if (position > 0) {
        position--;
      }
      return;
    }

    // Ignore modifier keys alone
    if (["Control", "Alt", "Shift", "Meta", "CapsLock", "Tab"].includes(e.key)) {
      return;
    }

    // Ignore key combos with Ctrl/Alt/Meta (except Shift)
    if (e.ctrlKey || e.altKey || e.metaKey) {
      return;
    }

    // Check if we have more characters
    if (position >= clipboardText.length) {
      e.preventDefault();
      e.stopPropagation();
      deactivate();
      return;
    }

    // Prevent default key action
    e.preventDefault();
    e.stopPropagation();

    // Get current character and insert it
    const char = clipboardText[position];
    const target = document.activeElement;
    
    insertChar(char, target);
    position++;

    // Auto-deactivate when done
    if (position >= clipboardText.length) {
      setTimeout(deactivate, 100);
    }
  }

  // Listen for activation message from background
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "activate") {
      if (active) {
        deactivate();
      } else {
        activate();
      }
    }
  });

  // Capture keydown at the highest priority
  document.addEventListener("keydown", handleKeyDown, true);

  console.log("Clipboard Typer loaded. Press Alt+X to activate.");
})();
